/*
 * Param.c
 *
 *  Created on: Mar 27, 2025
 *      Author: leecurrent04
 *      Email : leecurrent04@inha.edu
 */


/* Includes ------------------------------------------------------------------*/
#include <FC_Param/Param.h>


/* Variables -----------------------------------------------------------------*/
PARAM param;


/* Functions -----------------------------------------------------------------*/

