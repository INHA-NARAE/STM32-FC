/*
 * IMU.c
 *
 *  Created on: April 30, 2025
 *      Author: leecurrent04
 *      Email : leecurrent04@inha.edu
 */


/* Includes ------------------------------------------------------------------*/
#include <FC_AHRS/FC_IMU/IMU.h>
#include <GCS_MAVLink/GCS_MAVLink.h>
#include <FC_AHRS/FC_IMU/Madgwick.h>
#include <math.h>
/* Functions -----------------------------------------------------------------*/
/*
 * @brief IMU 초기화
 * @detail IMU 1 - ICM42688P : GYRO, ACC, TEMP
 * @parm none
 * @retval 0
 */
int IMU_Initialization(void)
{
	LL_GPIO_SetOutputPin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin);

	ICM42688_Initialization();

	LL_GPIO_ResetOutputPin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin);
	return 0;
}


/*
 * @brief 데이터 로딩
 * @detail SCALED_IMU(2,3)에 저장
 * @parm none
 * @retval none
 */
unsigned int IMU_GetData(void)
{


	// SCALED_IMU
	 ICM42688_GetData();


	// SCALED_IMU2
	// SCALED_IMU3
//	MadgwickFilter
    float ax = (float)msg.scaled_imu.xacc / 1000.0f; // mG → G
    float ay = (float)msg.scaled_imu.yacc / 1000.0f; // mG → G
    float az = (float)msg.scaled_imu.zacc / 1000.0f; // mG → G

    float gx = (float)msg.scaled_imu.xgyro / 1000.0f; // mdeg/s → deg/s
    float gy = (float)msg.scaled_imu.ygyro / 1000.0f; // mdeg/s → deg/s
    float gz = (float)msg.scaled_imu.zgyro / 1000.0f; // mdeg/s → deg/s

    gx *= M_PI / 180.0f; // deg/s → rad/s
    gy *= M_PI / 180.0f;
    gz *= M_PI / 180.0f;

    MadgwickAHRSupdateIMU(gx, gy, gz, ax, ay, az); // 필터 업데이트
//	ComplementaryFilter();
//	KalmanFilter();

	return 0;
}


/* Functions -----------------------------------------------------------------*/
void KalmanFilter(void)
{
	return;
}


void ComplementaryFilter(void)
{
	return;
}
