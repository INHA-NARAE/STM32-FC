/*
 * Madgwick.c
 *
 *  Created on: Jul 3, 2025
 *      Author: rlawn
 */


