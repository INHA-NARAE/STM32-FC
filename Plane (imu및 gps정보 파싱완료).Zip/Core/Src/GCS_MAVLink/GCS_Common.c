/*
 * GCS_Common.c
 *
 *  Created on: Mar 27, 2025
 *      Author: leecurrent04
 *      Email : leecurrent04@inha.edu
 */


/* Includes ------------------------------------------------------------------*/
#include <GCS_MAVLink/GCS_MAVLink.h>


/* Variables -----------------------------------------------------------------*/
Common msg;


/* Functions -----------------------------------------------------------------*/
