/*
 * register_map.c
 * FC_AHRS/FC_IMU/BMI323/BMI323.c
 *
 *  Created on: June 19, 2025
 *      Author: leecurrent04
 *      Email : leecurrent04@inha.edu
 */

#ifndef INC_FC_AHRS_FC_IMU_BMI323_REGISTER_MAP_H_
#define INC_FC_AHRS_FC_IMU_BMI323_REGISTER_MAP_H_


// USER BANK 0 REGISTER

// USER BANK 1 REGISTER


// USER BANK 2 REGISTER


// USER BANK 3 REGISTER


// USER BANK 4 REGISTER


#endif /* INC_FC_AHRS_FC_IMU_BMI323_REGISTER_MAP_H_ */
